#ifndef _CONFIG_H_
#define _CONFIG_H_
		
#define HAVE_LIBUPNP
#define PACKAGE_NAME "gmrender-resurrect"
#define PACKAGE_STRING "gmrender-resurrect"
#define GM_COMPILE_VERSION	"0.0.9"
#define PKG_DATADIR		"./"

#endif
